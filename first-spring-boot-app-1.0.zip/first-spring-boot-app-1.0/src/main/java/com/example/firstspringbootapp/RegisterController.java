package com.example.firstspringbootapp;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegisterController {
    
	@RequestMapping(value="/" ,method = RequestMethod.GET)
	public String ShowRegisterPage(ModelMap model) {
	
		return "register"; 
	}
	
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String ShowLoginPage(ModelMap model, @RequestParam String name) {
		
	
		return "login"; 
	}
	
	@RequestMapping(value="/welcome", method = RequestMethod.POST)
	public String ShowWelcomePage(ModelMap model, @RequestParam String name) {
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy h:mm:ss a");
		String formattedDate = sdf.format(date);
	    model.put("name",name);
	    model.put("formattedDate",formattedDate);
		return "welcome"; 
	}
}
